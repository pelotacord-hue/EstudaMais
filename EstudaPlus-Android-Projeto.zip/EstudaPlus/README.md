# Estuda+ — Android

Aplicativo Android em Kotlin + Jetpack Compose, com interface escura e módulos de simulados, matérias, redação e Professor IA.

## O que já está implementado
- Tela inicial e navegação inferior.
- Áreas de preparação: ENEM, SENAI-MG Jovem Aprendiz, PISM e PASES.
- Simulado demonstrativo com questões de Português e Matemática, alternativas, correção e resultado.
- Aba de matérias gerais.
- Professor IA conectado a um endpoint seguro.
- Redação com solicitação de correção baseada nas cinco competências do ENEM.
- Configuração do endereço do servidor dentro do aplicativo.
- GitHub Actions para gerar o APK debug.

> Importante: os simulados incluídos são questões demonstrativas inéditas, não provas oficiais. A correção da redação pela IA é uma estimativa pedagógica, não uma nota oficial.

## Gerar APK pelo GitHub
1. Crie um repositório no GitHub.
2. Envie o conteúdo desta pasta para a raiz do repositório (não envie a pasta ZIP dentro do repositório).
3. Abra a aba **Actions**.
4. Se necessário, habilite GitHub Actions.
5. Execute **Build Estuda+ APK** em **Run workflow**, ou faça um commit.
6. Ao terminar, abra a execução e baixe o artefato **EstudaPlus-apk**.
7. Dentro dele estará `app-debug.apk`.

## Ativar o Professor IA (Cloudflare Worker)
A aplicação móvel nunca deve conter a chave secreta da OpenAI. O Worker funciona como servidor intermediário.

1. Crie uma conta na Cloudflare e instale o Wrangler no computador, ou use o fluxo de deploy pelo painel/Cloudflare Workers.
2. Entre na pasta `worker`.
3. Publique o Worker usando Wrangler: `npx wrangler deploy`.
4. Configure o segredo: `npx wrangler secret put OPENAI_API_KEY`.
5. Cole sua chave da API quando solicitado. Não a coloque no aplicativo, no GitHub ou em mensagens.
6. Opcionalmente configure o modelo com `npx wrangler secret put OPENAI_MODEL` (ou variável no painel).
7. Copie a URL pública do Worker, por exemplo `https://estudamais-api.<sua-conta>.workers.dev`.
8. Abra o Estuda+, toque na engrenagem e cole essa URL.

A API da OpenAI é cobrada separadamente conforme o uso e a conta da plataforma. Criar uma chave não significa ter créditos gratuitos.

## Requisitos de build
- JDK 17
- Gradle 8.9
- Android SDK 35
- Android Gradle Plugin 8.7.3

## Observações de segurança antes de publicar
O Worker deste projeto é uma base inicial. Antes de abrir o serviço ao público, adicione autenticação, limites de requisição por usuário/IP, monitoramento de custos e regras contra abuso. CORS não é autenticação. Nunca publique a chave da API.

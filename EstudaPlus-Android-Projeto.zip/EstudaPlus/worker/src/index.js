const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    const url = new URL(request.url);
    if (url.pathname !== "/ask" || request.method !== "POST") {
      return Response.json({ error: "Not found" }, { status: 404, headers: cors });
    }
    if (!env.OPENAI_API_KEY) {
      return Response.json({ error: "Configure o secret OPENAI_API_KEY." }, { status: 500, headers: cors });
    }
    try {
      const body = await request.json();
      const prompt = String(body.prompt || "").slice(0, 12000);
      if (!prompt.trim()) return Response.json({ error: "Pergunta vazia." }, { status: 400, headers: cors });

      const upstream = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: env.OPENAI_MODEL || "gpt-6-astra",
          instructions: "Você é o Professor IA do Estuda+, uma plataforma educacional em português do Brasil. Seja didático, correto e honesto. Explique conceitos e resolva exercícios passo a passo. Em redações, use critérios do ENEM e deixe claro que a nota é estimada.",
          input: prompt,
          max_output_tokens: 1800
        })
      });
      const data = await upstream.json();
      if (!upstream.ok) {
        return Response.json({ error: data.error?.message || "Falha na API de IA." }, { status: upstream.status, headers: cors });
      }
      const answer = (data.output || [])
        .filter(item => item.type === "message")
        .flatMap(item => item.content || [])
        .filter(part => part.type === "output_text")
        .map(part => part.text)
        .join("\n");
      return Response.json({ answer: answer || "A IA não retornou texto." }, { headers: cors });
    } catch (err) {
      return Response.json({ error: "Erro ao processar a solicitação." }, { status: 500, headers: cors });
    }
  }
};

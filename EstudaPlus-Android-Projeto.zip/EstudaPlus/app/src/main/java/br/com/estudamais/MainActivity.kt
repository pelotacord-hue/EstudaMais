package br.com.estudamais

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.json.JSONArray
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Panel2 = Color(0xFF222222)
private val Accent = Color(0xFFE5E5E5)
private val Muted = Color(0xFF9B9B9B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("estuda", MODE_PRIVATE)
        setContent {
            var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "") ?: "") }
            EstudaApp(endpoint, onEndpoint = {
                endpoint = it
                prefs.edit().putString("endpoint", it).apply()
            })
        }
    }
}

@Composable
fun EstudaApp(endpoint: String, onEndpoint: (String) -> Unit) {
    var tab by remember { mutableStateOf("Início") }
    var selectedExam by remember { mutableStateOf("SENAI-MG Jovem Aprendiz") }
    var showSettings by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Color.White,
        onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
    )) {
    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("ESTUDA+", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("Seu próximo passo começa estudando.", color = Muted, fontSize = 11.sp)
                }
                Text("⚙", color = Color.White, fontSize = 22.sp, modifier = Modifier.clickable { showSettings = true }.padding(6.dp))
            }
            Box(Modifier.weight(1f)) {
                when (tab) {
                    "Início" -> HomeScreen(
                        onGo = { tab = it },
                        onExam = { selectedExam = it; tab = "Simulados" }
                    )
                    "Simulados" -> QuizScreen(selectedExam)
                    "Estudar" -> StudyScreen()
                    "Redação" -> EssayScreen(endpoint)
                    "Professor IA" -> AiScreen(endpoint)
                }
            }
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                listOf("Início", "Simulados", "Estudar", "Redação", "Professor IA").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Text(when(item) { "Início" -> "⌂"; "Simulados" -> "▤"; "Estudar" -> "▣"; "Redação" -> "✎"; else -> "✦" }, fontSize = 18.sp) },
                        label = { Text(item, fontSize = 9.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White, selectedTextColor = Color.White,
                            indicatorColor = Color(0xFF393939), unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                containerColor = Panel,
                title = { Text("Configurar inteligência artificial", color = Color.White) },
                text = {
                    Column {
                        Text("URL do seu servidor seguro (Cloudflare Worker):", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        var value by remember { mutableStateOf(endpoint) }
                        OutlinedTextField(value, { value = it }, placeholder = { Text("https://seu-worker.workers.dev") })
                        Text("Não coloque sua chave secreta da OpenAI aqui.", color = Color(0xFFFFB4AB), fontSize = 11.sp)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { onEndpoint(value.trim()); showSettings = false }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Text("Salvar endereço") }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Fechar", color = Color.White) } }
            )
        }
    }
    }
}

@Composable
fun HomeScreen(onGo: (String) -> Unit, onExam: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Box(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(20.dp)) {
            Column {
                Text("BEM-VINDO AO ESTUDA+", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(10.dp))
                Text("Aprenda no seu ritmo.\nChegue mais preparado.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, lineHeight = 31.sp)
                Spacer(Modifier.height(8.dp))
                Text("Simulados, matérias, redação e um professor com IA.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick = { onGo("Simulados") }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Text("Começar a estudar  →") }
            }
        }
        Spacer(Modifier.height(22.dp))
        SectionTitle("PREPARE-SE PARA")
        val exams = listOf("ENEM", "SENAI-MG Jovem Aprendiz", "PISM", "PASES")
        exams.forEach { exam ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(14.dp))
                .clickable { onExam(exam) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(exam, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Questões e prática direcionada", color = Muted, fontSize = 11.sp)
                }
                Text("→", color = Color.White, fontSize = 20.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        SectionTitle("SEU ESPAÇO DE APRENDIZADO")
        FeatureCard("✦", "Professor IA", "Tire dúvidas e peça explicações.", onClick = { onGo("Professor IA") })
        FeatureCard("✎", "Redação", "Escreva, receba correções e evolua.", onClick = { onGo("Redação") })
        FeatureCard("▣", "Matérias gerais", "Estude conteúdos do ensino médio.", onClick = { onGo("Estudar") })
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(bottom = 9.dp))
}
@Composable
fun FeatureCard(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(14.dp))
        .clickable { onClick() }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, color = Color.White, fontSize = 22.sp, modifier = Modifier.padding(end = 14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Text("›", color = Muted, fontSize = 23.sp)
    }
}

data class Question(val prompt: String, val options: List<String>, val answer: Int, val explanation: String)
@Composable
fun QuizScreen(exam: String) {
    val questions = remember(exam) { sampleQuestions(exam) }
    var index by remember(exam) { mutableIntStateOf(0) }
    var selected by remember(exam) { mutableIntStateOf(-1) }
    var score by remember(exam) { mutableIntStateOf(0) }
    var finished by remember(exam) { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("SIMULADOS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        Text(exam, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        if (finished) {
            Text("Simulado concluído!", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Você acertou $score de ${questions.size} questões.", color = Muted)
            Spacer(Modifier.height(15.dp))
            Button(onClick = { index = 0; selected = -1; score = 0; finished = false }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Text("Refazer simulado") }
        } else {
            Text("Questão ${index + 1} de ${questions.size}", color = Muted)
            LinearProgressIndicator(progress = { (index + 1f) / questions.size }, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), color = Color.White, trackColor = Panel2)
            val q = questions[index]
            Text(q.prompt, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(15.dp))
            q.options.forEachIndexed { i, option ->
                val chosen = selected == i
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(if (chosen) Color(0xFF3A3A3A) else Panel, RoundedCornerShape(12.dp))
                    .clickable(enabled = selected == -1) { selected = i; if (i == q.answer) score++ }
                    .padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${'A' + i}", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(option, color = Color.White, modifier = Modifier.padding(start = 12.dp))
                }
            }
            if (selected != -1) {
                Spacer(Modifier.height(12.dp))
                Text(if (selected == q.answer) "Correto!" else "Resposta correta: ${'A' + q.answer}", color = Color.White, fontWeight = FontWeight.Bold)
                Text(q.explanation, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { if (index == questions.lastIndex) finished = true else { index++; selected = -1 } },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                    Text(if (index == questions.lastIndex) "Ver resultado" else "Próxima questão")
                }
            }
        }
    }
}
fun sampleQuestions(exam: String): List<Question> {
    val math = Question("Uma camiseta custa R$ 80,00 e recebe desconto de 25%. Qual é o preço final?",
        listOf("R$ 55,00", "R$ 60,00", "R$ 65,00", "R$ 70,00"), 1,
        "25% de 80 = 20. Então, 80 − 20 = R$ 60,00.")
    val portuguese = Question("Em um texto argumentativo, a tese corresponde:",
        listOf("Ao título do texto", "À opinião central defendida", "A um exemplo isolado", "À conclusão obrigatória"), 1,
        "A tese é o ponto de vista central que será defendido pelos argumentos.")
    val fraction = Question("Qual é o resultado de 1/2 + 1/4?",
        listOf("1/6", "2/6", "3/4", "1/8"), 2,
        "Transforme 1/2 em 2/4. Assim, 2/4 + 1/4 = 3/4.")
    return if (exam.contains("SENAI")) listOf(math, portuguese, fraction) else listOf(portuguese, math, fraction)
}

@Composable
fun StudyScreen() {
    val subjects = listOf("Matemática", "Física", "Química", "Biologia", "Português", "História", "Geografia", "Inglês", "Filosofia", "Sociologia")
    var chosen by remember { mutableStateOf("Matemática") }
    var topic by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("MATÉRIAS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        Text("O que você quer aprender?", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(15.dp))
        subjects.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { subject ->
                    Box(Modifier.weight(1f).padding(vertical = 4.dp).background(if (chosen == subject) Panel2 else Panel, RoundedCornerShape(12.dp))
                        .clickable { chosen = subject }.padding(15.dp)) { Text(subject, color = Color.White) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(15.dp))
        Text("Conteúdo específico", color = Color.White, fontWeight = FontWeight.SemiBold)
        OutlinedTextField(topic, { topic = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Ex.: equação do 1º grau") })
        Text("Escolha uma matéria e use o Professor IA para pedir uma aula, resumo ou lista de exercícios.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun AiScreen(endpoint: String) {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Olá! Sou seu Professor IA. Pergunte sobre qualquer matéria, envie um exercício ou peça uma explicação passo a passo.") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("PROFESSOR IA", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        Text("Tire suas dúvidas.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(15.dp)) {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("ESTUDA+ IA", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(answer, color = Color.White, fontSize = 14.sp)
                if (loading) { Spacer(Modifier.height(10.dp)); CircularProgressIndicator(color = Color.White) }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(question, { question = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Digite sua pergunta...") })
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            if (question.isNotBlank() && !loading) {
                val q = question
                question = ""
                loading = true
                scope.launch {
                    answer = askAi(endpoint, "Você é o Professor IA do Estuda+, tutor brasileiro. Explique com clareza, passo a passo, em linguagem adequada a um estudante do ensino médio. Se for exercício, mostre o raciocínio e a resposta. Pergunta: $q")
                    loading = false
                }
            }
        }, enabled = !loading && question.isNotBlank(), modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Text(if (loading) "Pensando..." else "Perguntar à IA  →") }
        if (endpoint.isBlank()) Text("Configure o endereço do servidor no botão ⚙ do topo para ativar a IA.", color = Color(0xFFFFB4AB), fontSize = 11.sp)
    }
}

@Composable
fun EssayScreen(endpoint: String) {
    var theme by remember { mutableStateOf("Os desafios da educação no Brasil") }
    var essay by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("REDAÇÃO", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        Text("Treine sua escrita.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("TEMA", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(theme, { theme = it }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Text("SUA REDAÇÃO", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(essay, { essay = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 230.dp), placeholder = { Text("Digite sua redação aqui...") })
        Text("${essay.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.size} palavras", color = Muted, fontSize = 11.sp)
        Button(onClick = {
            if (essay.isNotBlank() && !loading) {
                loading = true; result = ""
                scope.launch {
                    result = askAi(endpoint, "Corrija esta redação no modelo ENEM sobre o tema '$theme'. Avalie as cinco competências, dê nota estimada de 0 a 200 em cada uma e total de 0 a 1000. Explique pontos fortes, problemas e melhorias concretas. Não invente critérios. Texto: $essay")
                    loading = false
                }
            }
        }, enabled = essay.isNotBlank() && !loading, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Text(if (loading) "Corrigindo..." else "Corrigir com IA") }
        if (result.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            Text("CORREÇÃO", color = Color.White, fontWeight = FontWeight.Bold)
            Text(result, color = Muted, fontSize = 13.sp)
        }
        if (endpoint.isBlank()) Text("Configure o servidor da IA nas configurações para corrigir redações.", color = Color(0xFFFFB4AB), fontSize = 11.sp)
    }
}

suspend fun askAi(endpoint: String, prompt: String): String = withContext(Dispatchers.IO) {
    if (endpoint.isBlank()) return@withContext "A inteligência artificial ainda não está configurada. Abra ⚙ e informe a URL do servidor seguro."
    try {
        val client = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build()
        val payload = JSONObject().put("prompt", prompt).toString()
        val request = Request.Builder().url(endpoint.trimEnd('/') + "/ask")
            .post(payload.toRequestBody("application/json".toMediaType())).build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) return@withContext "Não foi possível consultar a IA (HTTP ${response.code}). Verifique o servidor."
            JSONObject(body).optString("answer", "A IA não retornou uma resposta.")
        }
    } catch (e: Exception) {
        "Não consegui conectar ao servidor. Confira a URL e sua conexão com a internet."
    }
}
